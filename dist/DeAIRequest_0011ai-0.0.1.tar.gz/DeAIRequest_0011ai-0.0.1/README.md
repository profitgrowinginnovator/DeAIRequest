# The Decentralised AI Request 

Enable for any AI python code to be executed on decentralised AI compute.

Supported AI compute:
[Bacalhau](https://bacalhau.org)
