

"""
Create a decentralised AI request
"""
class DeAIRequest:

    """
    Specify the protocol you want to use 
    @oaram self:
    @param deprotocol: specify which protocol you want to run the decentralised AI request on
    """
    def __init__(self, deprotocol):
        self.deprotocol = deprotocol    

    """
    Submit a job to the specified protocol with the 
    @oaram self:
    @param ipynb: the Jupyter (Lab) Notebook to run remotely
    @param params: optional parameters
    @return: the job ID
    """
    @classmethod
    def submit_job(self, ipynb, params=""):
        return self.deprotocol.submit_job(self, ipynb, params)


    """
    Get the logs from the protocol request 
    @oaram self:
    @param job: the job id
    @return: the logs of the current protocol job
    @raises: exception if the job id is not known
    """
    @classmethod
    def get_logs(self, job):
        return self.deprotocol.get_logs(self,job)